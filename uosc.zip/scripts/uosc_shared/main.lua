--[[
File required for compatibility between mpv:
- 0.32 - doesn't support `dir/main.lua`, so we need `uosc.lua` in root
- 0.33 - requires `main.lua` in directories
]]
